from django.apps import AppConfig


class BookmgmtappConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bookmgmtapp'
