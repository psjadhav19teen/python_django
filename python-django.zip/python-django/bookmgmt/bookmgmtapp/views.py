from django.shortcuts import render
from django.http import HttpResponse
from .models import *
from django.contrib import messages
from django.shortcuts import redirect

def index(request):
    return render(request,'index.html')

def add_book(request):
    if request.method=='POST':
        title=request.POST['title']
        author=request.POST['author']
        price=request.POST['price']
        book=Book(title=title,author=author,price=price)
        book.save()
        messages.info(request,'Book added')
    else:
        pass
    book_list=Book.objects.all()
    context={'book_list':book_list}
    return render(request,'index.html',context)

def delete_book(request,myid):
    book=Book.objects.get(id=myid)
    book.delete()
    messages.info(request,'Book deleted successfully')
    return redirect(index)